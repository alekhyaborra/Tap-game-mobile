export declare class CanvasWhiteboardModule {
}
