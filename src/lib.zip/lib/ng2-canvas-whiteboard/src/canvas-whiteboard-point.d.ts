export declare class CanvasWhiteboardPoint {
    x: number;
    y: number;
    constructor(x: number, y: number);
}
