export * from './src/ng2-canvas-whiteboard';
