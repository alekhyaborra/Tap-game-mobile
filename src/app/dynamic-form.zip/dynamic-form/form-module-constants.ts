export  class  FormModuleconstants {
    public static retake = "RETAKE";
    public static close = "CLOSE";
    public static clear = "clear";
    public static save = "Save";
    public static rewrite= "Re-Write";
    public static barcodeFail = "Fail to capturing the Barcode";
    public static systemDate = "SystemDate";
    public static cameraActionList = ['Camera','Gallery'];
    public static systemGeneratedEntry = "System generated entry";
} 
