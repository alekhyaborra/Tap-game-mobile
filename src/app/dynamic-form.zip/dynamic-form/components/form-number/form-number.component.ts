import { Component, OnInit } from '@angular/core';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup } from '@angular/forms';
import { FormDataDistributionService } from '../../form-data-distribution.service';
import { widgetKeys } from '../../object-keys-constants';

@Component({
  selector: 'app-form-number',
  templateUrl: './form-number.component.html',
  styleUrls: ['./form-number.component.scss'],
})
export class FormNumberComponent implements OnInit {
  config: FieldConfig;
  group: FormGroup;
  widgetKey: any;
  groupName: any;
  expendedHeaderId: any;
  derivedFields: any;
  derivedFieldsCopy: any;
  isDerivedField: boolean = false;
  bOSubscribe: any;
  data: any;
  tableWidgetId: any;
  tableWidgetIndex: any;
  
  constructor(private formDataDistributionService:FormDataDistributionService){
    this.widgetKey = widgetKeys.keys;
  }
  specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-'];
  pattern = /[0-9]/;
  ngOnInit() {
    this.bOSubscribe = this.formDataDistributionService.hederOpen.subscribe(expendedHeaderId => {
      this.expendedHeaderId = expendedHeaderId;
    });
    
  }

  // keyPress(event){
    // if (this.specialKeys.indexOf(event.key) !== -1) {
    //   return;
    // }
    // event.preventDefault();
    // if(!this.pattern.test(event.key)){
    //   event.preventDefault();
    // }
  // }

  // numberOnly(event): boolean {
  //   const charCode = (event.which) ? event.which : event.keyCode;
  //   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //     return false;
  //   }
  //   return true;
  // }

  ngOnDestroy() {
    if (this.bOSubscribe) {
      this.bOSubscribe.unsubscribe();
    }
  }

}
