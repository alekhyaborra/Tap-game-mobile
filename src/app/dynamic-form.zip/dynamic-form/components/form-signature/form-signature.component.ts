import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { FieldConfig } from '../../models/field-config.interface';
import { ModalController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { SignatureViewModalComponent } from './signature-view-modal/signature-view-modal.component';
import { ImageViewerModalComponent } from '../image-viewer-modal/image-viewer-modal.component';
import { widgetKeys } from '../../object-keys-constants'
import { FormDataDistributionService } from '../../form-data-distribution.service'
import { FormModuleconstants } from '../../form-module-constants';
import { Base64ToGallery } from '@ionic-native/base64-to-gallery/ngx';
import { WebView } from '@ionic-native/ionic-webview/ngx';
import { File } from '@ionic-native/file/ngx';
import { CommonService } from '../../../sharedServices/commonServices/common.service';
import { LoadingService } from 'src/app/sharedServices/loading.service';
import { ApiUrls } from 'src/app/constants/api-urls';
import { RestApiService } from 'src/app/sharedServices/rest-api.service';
import { Constants } from 'src/app/constants/constants';
import { ToastService } from 'src/app/sharedServices/toast.service';

@Component({
  selector: 'app-form-signature',
  templateUrl: './form-signature.component.html',
  styleUrls: ['./form-signature.component.scss'],
})
export class FormSignatureComponent implements OnInit {
  config: FieldConfig;
  group: FormGroup;
  signatureDataValue:any
  widgetKey: any;
  signatureKey:any;
  historyView:boolean
  expendedHeaderId:any;
  derivedFields: any;
  derivedFieldsCopy: any;
  isDerivedField: boolean = false;
  bOSubscribe: any;
  data: any;
  tableWidgetId: any;
  tableWidgetIndex: any;
  isTable:boolean;

  constructor(private modalCtrl: ModalController,
    private storage: Storage,
    private formDataDistributionService: FormDataDistributionService,
    private base64ToGallery: Base64ToGallery,
    private webView: WebView,
    private file: File,
    private commonService: CommonService,
    private loader: LoadingService,
    private restApiService: RestApiService,
    private toastService:ToastService    
  ) {
    this.widgetKey = widgetKeys.keys;
  }

  get tableWidgetArray() {
    return this.group.get(this.tableWidgetId) as FormArray;
  }

  async openImage(img){
    const modal=await this.modalCtrl.create({
      component:ImageViewerModalComponent,
      componentProps:{
        imgData:img,
        Header:this.config[this.widgetKey.label],
        footer:FormModuleconstants.rewrite,
        change:this.openSignatureModal.bind(this),
        delete:this.deleteImage.bind(this),
        edit: false,
        historyView: this.historyView

      }
    });
    modal.present();
  }
  async openSignatureModal(signature){
    if(!this.historyView){
    this.signatureKey=signature
    const modal=await this.modalCtrl.create({
      component:SignatureViewModalComponent,
      componentProps:{
        signature:signature,
        Header:this.config[this.widgetKey.label],
        change:this.signatureDataValue1.bind(this)
      }
    });
    modal.present();
  }else{
    // this.viewPreview()
  }
  }

  deleteImage(){
    let mediaData: any = [];
    mediaData = this.commonService.getMediaData() ? this.commonService.getMediaData() : [];
    let index = mediaData.findIndex(record => record.options.params.fieldId == this.config[widgetKeys.keys._id]);
    if (index > -1) {
      mediaData.splice(index, 1);
    }
    this.group.get(this.config[this.widgetKey._id]).setValue('');
    this.commonService.setMediaData(mediaData);
  }
  signatureDataValue1(img) {
    this.base64ToGallery.base64ToGallery(img, { prefix: '_img', mediaScanner: false }).then(
      res => {
        let mediaData: any = [];
        this.group.get(this.config[this.widgetKey._id]).setValue(this.webView.convertFileSrc(res));
        // this.signatureDataValue=img
        let imageName = res.substr(res.indexOf('_img'));
        let fullPath = res.substr(res.indexOf('/') + 1);
        mediaData = this.commonService.getMediaData() ? this.commonService.getMediaData() : [];
        let index = mediaData.findIndex(record => record.options.params.fieldId == this.config[this.widgetKey._id]);
        if (index > -1) {
          mediaData.splice(index, 1);
        }
        let options = {
          fileKey: "image",
          fileName: imageName,
          chunkedMode: false,
          mimeType: "png",
          params: {
            fieldId: this.config[widgetKeys.keys._id]
          }
        };
        mediaData.push({ options: options, path: fullPath });
        this.commonService.setMediaData(mediaData);
      },
      err => console.log('Error saving image to gallery ', err)
    );

  }
  viewPreview() {
    if (this.historyView || this.commonService.getWOData().recordStatus == Constants.statusValue["Reassigned"]) {
      this.loader.present()
      let imgUrl = ApiUrls.getImageorVideo + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      let url = ApiUrls.fetchImageOrVideoExists + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      const headers = this.restApiService.getHeadersForGet();
      try {
        this.restApiService.getServiceProcess(url, headers).subscribe(res => {
          this.loader.dismiss()
          if (res['status'] == 204) {
            this.toastService.showToast(Constants.noDataFound)
          }
          else if (res['status'] == 200) {
            this.openImage(imgUrl)
          }
        })
      } catch (e) {
        this.loader.dismiss()
        this.openImage(url)
      }
      // this.group.get(this.config[this.widgetKey._id]).setValue(url);
    }
  }
  ngOnInit() {
    if(this.group.get(this.config[this.widgetKey._id]).value && (this.commonService.getWOData().recordStatus == Constants.statusValue["Reassigned"] || this.historyView)){
      let imgUrl = ApiUrls.getImageorVideo + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      this.group.get(this.config[this.widgetKey._id]).setValue(imgUrl?imgUrl:'');
    }else{
          let sigValue = this.group.get(this.config[widgetKeys.keys._id]).value ? this.group.get(this.config[widgetKeys.keys._id]).value : '';
    this.group.get(this.config[widgetKeys.keys._id]).setValue(sigValue);

    }

     this.formDataDistributionService.hederOpen.subscribe(expendedHeaderId => {
      this.expendedHeaderId = expendedHeaderId;
    });
    const fieldIndex = this.derivedFields.indexOf(this.config[widgetKeys.keys._id])
    if (fieldIndex > -1) {
      this.isDerivedField = true;
      this.bOSubscribe = this.formDataDistributionService.derivedFieldRef.subscribe(derivedFields => {
        if (typeof derivedFields == widgetKeys.dataTypes.object) {
          const fieldIndex = derivedFields.indexOf(this.config[widgetKeys.keys._id])
          if (fieldIndex > -1) {
            this.isDerivedField = true;
            this.group.get(this.config[widgetKeys.keys._id]).reset();
          }
          else {
            if(this.data)
              this.group.get(this.config[widgetKeys.keys._id]).setValue(this.data[this.config[widgetKeys.keys._id]]);
            this.isDerivedField = false;
          }
        }
      });
    }
   }
  
  ngOnDestroy() {
    if (this.bOSubscribe) {
      this.bOSubscribe.unsubscribe();
    }
  }
}
