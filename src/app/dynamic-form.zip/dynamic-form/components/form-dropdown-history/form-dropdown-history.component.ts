import { Component, OnInit, Input } from '@angular/core';
import { ApiUrls } from '../../../constants/api-urls';
import { widgetKeys } from '../../object-keys-constants'
import { FormsService } from '../../../forms/forms.service';

@Component({
  selector: 'app-form-dropdown-history',
  templateUrl: './form-dropdown-history.component.html',
  styleUrls: ['./form-dropdown-history.component.scss'],
})
export class FormDropdownHistoryComponent implements OnInit {
  widgetKey: any;
  @Input()
  selectedValues: any;
  @Input()
  config: any;
  isDynamicDropDownCallFail = true;
 // selectedOptions:Array<string> = [];
  selectedOptions:any;
  constructor(private formsService: FormsService) {
    this.widgetKey = widgetKeys.keys;
   }

  ngOnInit() {
   this.dynamicDropDownOptionSetter();
  }

  dynamicDropDownOptionSetter() {
    console.log('dynamicDropDownOptionSetter');
    console.log(this.config);
    // Demo data
      const checkUrl =  ApiUrls.dynamicDropDwon + '/'
                       + this.config[this.widgetKey.dynamicDropdownTable] + '/' +
                       this.config[this.widgetKey.columnName];
      this.formsService.getDropDwonvalues(checkUrl)
        .subscribe(res => {
          console.log('responessssss');
          console.log(res);
          this.isDynamicDropDownCallFail = false;
          const obj = res['data'].map ((item) => {
            const emptyObj = {};
            emptyObj['displayValue'] = item ;
            emptyObj['value'] = item ;
            return emptyObj;
          });
          this.config[this.widgetKey.options] = obj;
          const index = this.config.options.findIndex(record => record.value === this.selectedValues.trim());
          this.selectedOptions = this.config.options[index].displayValue;
        }, error => {
          this.isDynamicDropDownCallFail = true;
        });
  }

}
