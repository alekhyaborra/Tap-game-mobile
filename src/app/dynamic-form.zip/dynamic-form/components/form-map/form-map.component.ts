import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { widgetKeys } from '../../object-keys-constants';
import { FormDataDistributionService } from '../../form-data-distribution.service';
import { GeoLocationService } from '../../../sharedServices/geo-location.service';
import { ToastService } from "../../../sharedServices/toast.service";
import { Constants } from '../../../constants/constants';

@Component({
  selector: 'app-form-map',
  templateUrl: './form-map.component.html',
  styleUrls: ['./form-map.component.scss'],
})
export class FormMapComponent implements Field {
  config: FieldConfig;
  group: FormGroup;
  widgetKey: any;
  groupName: any;
  expendedHeaderId: any;
  derivedFields: any;
  derivedFieldsCopy: any;
  isDerivedField: boolean = false;
  bOSubscribe: any;
  data: any;
  tableWidgetId: any;
  tableWidgetIndex: any;
  isTable:boolean;
  historyView:boolean;

  constructor(
    private formDataDistributionService: FormDataDistributionService,
    private geoLocationService: GeoLocationService,
    private toastService: ToastService
  ) {
    this.widgetKey = widgetKeys.keys;
  }

  get tableWidgetArray() {
    return this.group.get(this.tableWidgetId) as FormArray;
  }

  ngOnInit() {
    let locationValue = this.group.get(this.config[widgetKeys.keys._id]).value ? this.group.get(this.config[widgetKeys.keys._id]).value : '';
    this.group.get(this.config[widgetKeys.keys._id]).setValue(locationValue);
    this.bOSubscribe = this.formDataDistributionService.hederOpen.subscribe(expendedHeaderId => {
      this.expendedHeaderId = expendedHeaderId;
    });
  }

  getLocation(id) {
    if (!this.historyView && !this.config[widgetKeys.keys.disabled]) {
    this.geoLocationService.getLatLong().then((resp) => {
      const latLong = resp.coords.latitude + ',' + resp.coords.longitude;
      this.group.get(id).setValue(latLong);
    }).catch((error) => {
      this.toastService.showToast(Constants.unableToGetLocation);
    });
  }
  }

  ngOnDestroy() {
    if (this.bOSubscribe) {
      this.bOSubscribe.unsubscribe();
    }
  }
}
