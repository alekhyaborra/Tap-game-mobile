import { Component, OnInit } from '@angular/core';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup, FormArray } from '@angular/forms';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { ModalController, PopoverController } from '@ionic/angular';
import { ImageViewerModalComponent } from '../image-viewer-modal/image-viewer-modal.component';
import { widgetKeys } from '../../object-keys-constants';
import { FormDataDistributionService } from '../../form-data-distribution.service';
import { Constants } from '../../../constants/constants';
import { ModalsService } from '../../../sharedServices/modals.service';
import { EllipsePopoverComponent } from '../../../sharedComponents/ellipse-popover/ellipse-popover.component';
import { FormModuleconstants } from '../../form-module-constants';
import { CommonService } from '../../../sharedServices/commonServices/common.service';
import { WebView } from '@ionic-native/ionic-webview/ngx';
import { File } from '@ionic-native/file/ngx';
import { Base64ToGallery } from '@ionic-native/base64-to-gallery/ngx';
import { FormDrawingComponent } from '../form-drawing/form-drawing.component';
import { ApiUrls } from 'src/app/constants/api-urls';
import { RestApiService } from 'src/app/sharedServices/rest-api.service';
import { ToastService } from 'src/app/sharedServices/toast.service';
import { LoadingService } from 'src/app/sharedServices/loading.service';
import * as watermark from 'watermarkjs';
import { GeoLocationService } from '../../../sharedServices/geo-location.service';

@Component({
  selector: 'form-camera',
  templateUrl: './form-camera.component.html',
  styleUrls: ['./form-camera.component.scss'],
})
export class FormCameraComponent implements Field, OnInit {

  nullValue = Constants.nullValue;
  config: FieldConfig;
  group: FormGroup;
  imageCaptured: any;
  widgetKey: any;
  historyView: boolean;
  expendedHeaderId: any;
  derivedFields: any;
  derivedFieldsCopy: any;
  isDerivedField: boolean = false;
  bOSubscribe: any;
  data: any;
  cameraSource = this.camera.PictureSourceType.CAMERA;
  gallerySourc = this.camera.PictureSourceType.PHOTOLIBRARY;
  tableWidgetId: any;
  tableWidgetIndex: any;
  isTable: boolean;

  constructor(
    private camera: Camera,
    private modalController: ModalController,
    private formDataDistributionService: FormDataDistributionService,
    private modalsService: ModalsService,
    private commonService: CommonService,
    private webView: WebView,
    private file: File,
    private base64ToGallery: Base64ToGallery,
    private popoverController: PopoverController,
    private restApiService: RestApiService,
    private toastService: ToastService,
    private loader: LoadingService,
    private geoLocationService: GeoLocationService
  ) {
    this.widgetKey = widgetKeys.keys;
  }

  async openImage(img) {
    const modal = await this.modalController.create({
      component: ImageViewerModalComponent,
      componentProps: {
        imgData: img,
        Header: this.config[this.widgetKey.label],
        footer: FormModuleconstants.retake,
        change: this.retakeImage.bind(this),
        annotated: this.imageAnnotation.bind(this),
        delete: this.deleteImage.bind(this),
        fieldid: this.config[widgetKeys.keys._id],
        edit: true,
        historyView: this.historyView
      }
    });
    modal.present();
  }
  imageAnnotation(img) {
    this.watermarkImage(img);
  }
  watermarkImage(img) {
    this.geoLocationService.getLatLong().then((resp) => {
      const today = new Date();
      const date = (today.getMonth() + 1) + '-' +  today.getDate() + '-' + today.getFullYear();
      const latLong = resp.coords.latitude + ',' + resp.coords.longitude;
      this.placWatermarkProcess(img, latLong + '   ' + date);
      this.toastService.showToast('Geo tag added successfully on top of image');
    }).catch((error) => {
    this.toastService.showToast(Constants.unableToGetLocation);
    //  this.toastService.showToast('Geo tag added successfully on top of image');
    });
  }
  placWatermarkProcess(img, text) {
    watermark([img])
    .image(watermark.text.lowerRight( text, '22px Arial', '#0099cc', 0.9))
      .then(image => {
        console.log(image.src);
        console.log('insidee then');
        this.base64ToGallery.base64ToGallery(image.src, { prefix: '_img', mediaScanner: false }).then(
          res => {
            let mediaData: any = [];
            this.group.get(this.config[this.widgetKey._id]).setValue(this.webView.convertFileSrc(res));
            // this.signatureDataValue=img
            let imageName = res.substr(res.indexOf('_img'));
            let fullPath = res.substr(res.indexOf('/') + 1);
            mediaData = this.commonService.getMediaData() ? this.commonService.getMediaData() : [];
            let index = mediaData.findIndex(record => record.options.params.fieldId == this.config[this.widgetKey._id]);
            if (index > -1) {
              mediaData.splice(index, 1);
            }
            let options = {
              fileKey: "image",
              fileName: imageName,
              chunkedMode: false,
              mimeType: "png",
              params: {
                fieldId: this.config[widgetKeys.keys._id]
              }
            };
            mediaData.push({ options: options, path: fullPath });
            this.commonService.setMediaData(mediaData);
          },
          err => console.log('Error saving image to gallery ', err)
        );
      });
  }


  async drawImage(img) {
    const modal = await this.modalController.create({
      component: FormDrawingComponent,
      componentProps: {
        imgData: img,
        changeStatus: this.imageAnnotation.bind(this)
      }
    });
    modal.present();
  }
  cameraCapture(formcontrolNameRef: any, sourceTypeVal) {
    this.popoverController.dismiss()
    const options: CameraOptions = {
      quality: 20,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true,
      sourceType: sourceTypeVal
    };
    let correctPath;
    let currentName;
    this.camera.getPicture(options).then((imageData) => {
      this.imageCaptured = imageData;
      correctPath = imageData.substr(0, imageData.lastIndexOf('/') + 1);
      if (sourceTypeVal === this.cameraSource) {
        currentName = imageData.substring(imageData.lastIndexOf('/') + 1);
        this.imageCaptured = this.imageCaptured.substring(8);
      } else {
        currentName = imageData.substring(imageData.lastIndexOf('/') + 1, imageData.lastIndexOf('?'));
        this.imageCaptured = this.imageCaptured.substring(8, this.imageCaptured.lastIndexOf('?'));
      }

      this.copyFileToLocalDir(correctPath, currentName, currentName, formcontrolNameRef);
    }, (err) => {
    });
  }

  copyFileToLocalDir(namePath, currentName, newFileName, formcontrolNameRef) {

    let mediaData: any = [];
    this.file.copyFile(namePath, currentName, this.file.dataDirectory, newFileName).then(success => {
      mediaData = this.commonService.getMediaData() ? this.commonService.getMediaData() : [];
      let index = mediaData.findIndex(record => record.options.params.fieldId == formcontrolNameRef);
      if (index > -1) {
        mediaData.splice(index, 1);
      }
      let options = {
        fileKey: "image",
        fileName: currentName,
        chunkedMode: false,
        mimeType: "JPEG",
        params: {
          fieldId: this.config[widgetKeys.keys._id]
        }
      };
      mediaData.push({ options: options, path: this.imageCaptured });
      // console.log(this.webView.convertFileSrc(this.file.dataDirectory + currentName));
      // console.log(this.file.dataDirectory + currentName);
      this.drawImage(this.webView.convertFileSrc(this.file.dataDirectory + currentName))
      this.group.get(formcontrolNameRef).setValue(this.webView.convertFileSrc(this.file.dataDirectory + currentName));
      this.commonService.setMediaData(mediaData);
    }, error => {
      console.log(error)
    });
  }

  retakeImage(event) {
    this.cameraCapture(this.config[this.widgetKey._id], this.cameraSource);
  }
  deleteImage() {
    this.imageCaptured = this.nullValue;
    let mediaData: any = [];
    mediaData = this.commonService.getMediaData() ? this.commonService.getMediaData() : [];
    let index = mediaData.findIndex(record => record.options.params.fieldId == this.config[widgetKeys.keys._id]);
    if (index > -1) {
      mediaData.splice(index, 1);
    }
    this.group.get(this.config[widgetKeys.keys._id]).setValue("");
    this.commonService.setMediaData(mediaData);
  }

  get tableWidgetArray() {
    return this.group.get(this.tableWidgetId) as FormArray;
  }
  viewPreview() {
    if (this.historyView) {
      this.loader.present()
      let imgUrl = ApiUrls.getImageorVideo + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      let url = ApiUrls.fetchImageOrVideoExists + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      const headers = this.restApiService.getHeadersForGet();
      try {
        this.restApiService.getServiceProcess(url, headers).subscribe(res => {
          this.loader.dismiss()
          if (res['status'] == 204) {
            this.toastService.showToast(Constants.noDataFound)

          }
          else if (res['status'] == 200) {
            this.openImage(imgUrl)
          }
        })
      } catch (e) {
        this.loader.dismiss()
        this.openImage(url)
      }
    }
  }
  ngOnInit() {
    if (this.group.get(this.config[this.widgetKey._id]).value && (this.commonService.getWOData().recordStatus == Constants.statusValue["Reassigned"] || this.historyView)) {
      let imgUrl = ApiUrls.getImageorVideo + "/" + this.commonService.getRecordId() + "/" + this.config[widgetKeys.keys._id]
      this.group.get(this.config[this.widgetKey._id]).setValue(imgUrl?imgUrl:'');

    }else{
          let camValue = this.group.get(this.config[widgetKeys.keys._id]).value ? this.group.get(this.config[widgetKeys.keys._id]).value : '';
    this.group.get(this.config[widgetKeys.keys._id]).setValue(camValue);

    }
    this.bOSubscribe = this.formDataDistributionService.hederOpen.subscribe(expendedHeaderId => {
      this.expendedHeaderId = expendedHeaderId;
    });

  }

  ngOnDestroy() {
    if (this.bOSubscribe) {
      this.bOSubscribe.unsubscribe();
    }
  }

  getImage(event, id) {
    if (!this.historyView) {
      const componentProps = {
        popoverList: FormModuleconstants.cameraActionList,
      }
      const that = this;
      this.modalsService.openPopover(EllipsePopoverComponent, 'custom-ellipse-popover', componentProps, event, function (data) {
        if (data == FormModuleconstants.cameraActionList[0])
          that.cameraCapture(id, that.cameraSource);
        else if (data == FormModuleconstants.cameraActionList[1])
          that.cameraCapture(id, that.gallerySourc);
      })
    } else {
      // this.viewPreview()
    }
  }
}
