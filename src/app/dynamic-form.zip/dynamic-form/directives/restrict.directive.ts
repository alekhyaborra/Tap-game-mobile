import { Directive, ElementRef, Input, HostListener } from '@angular/core';
// import * as Inputmask from 'inputmask';

@Directive({
  selector: '[appRestrict]'
})
export class RestrictDirective {

  // private regexMap = {
  //   integer: '^[0-9]*$'
  // };

  // constructor(private el: ElementRef) {}

  // @Input('appRestrict')
  // public set defineInputType(type: string) {
  //   Inputmask({regex: this.regexMap[type], placeholder: ''})
  //     .mask(this.el.nativeElement);
  // }
  private regex: RegExp = new RegExp(/^[0-9]*$/g);
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-'];
  constructor(private el: ElementRef) {
  }
  // @HostListener('keypress', ['$event'])
  // onKeyPress(event: KeyboardEvent) {
  // @HostListener('keydown', ['$event'])
  // onKeyDown(event: KeyboardEvent) {
  @HostListener('keyup', ['$event'])
  onKeyUp(event: KeyboardEvent) {
    // this.el.nativeElement.value = this.el.nativeElement.value+" ";
    // return false;
    // Allow Backspace, tab, end, and home keys
    // if (this.specialKeys.indexOf(event.key) !== -1) {
    //   return;
    // }
    if(event.key == "Unidentified"){
      this.el.nativeElement.value=this.el.nativeElement.value+" ";
      return;
    }
    // let current: string = this.el.nativeElement.value;
    // let next: string = current.concat(event.key);
    // if (next && !String(next).match(this.regex)) {
    //   event.preventDefault();
    // }
  }

}
