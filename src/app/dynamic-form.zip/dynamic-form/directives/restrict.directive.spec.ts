import { RestrictDirective } from './restrict.directive';

describe('RestrictDirective', () => {
  it('should create an instance', () => {
    const directive = new RestrictDirective();
    expect(directive).toBeTruthy();
  });
});
